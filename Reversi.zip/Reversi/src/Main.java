// Точка входа
public class Main {
    public static void main(String[] args) {
        // Запуск игровой сессии
        Session session = new Session();
        session.start();
    }
}